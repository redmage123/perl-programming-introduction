#!/usr/bin/perl


%cell_makes= {};
$cell_makes{'S9+'} = 'Samsung';
$cell_makes{'iPhone 10'} = 'Apple';

%cell_makes = {'S9+' => 'Samsung',
               'iPhone 10' => 'Apple'
              };

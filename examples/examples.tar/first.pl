#!/usr/bin/perl 


printf("Hello world\n");

printf("prompt: ");
my $foo = <>;
print ("foo = ",$foo,"\n");



#!/usr/bin/perl

$a= 5;

$a  = $a + 1;
printf("$a\n");
$a= 5;
$a++;
printf("$a\n");


$a = $a + 2;
$a += 2;

#!/usr/bin/perl

$name = "Braun";
$age = 21;

printf("Hi, my name is %s, and i am %d years old\n",$name,$age);

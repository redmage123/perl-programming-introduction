#!/usr/bin/perl

@colors = ('Red','Green','Blue');

push (@colors,"magenta");
unshift(@colors,'violet');
print(@colors);
print ("\n");

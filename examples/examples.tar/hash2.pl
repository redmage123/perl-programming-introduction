#!/usr/bin/perl

printf($ENV{'USER'});
printf("\n");
printf($ENV{'SHELL'});
printf("\n");
printf($ENV{'HOME'});
printf("\n");
